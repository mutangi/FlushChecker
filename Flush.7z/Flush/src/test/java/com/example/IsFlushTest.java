package com.example;

import com.example.IsFlush.Card;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;

public class IsFlushTest {

  private static final List<String> consecutiveCardsSameColors = new ArrayList<>(
      Arrays.asList("8c", "9c", "Tc", "Jc", "Qc"));
  private static final List<String> consecutiveCardsDifferentColors = new ArrayList<>(
      Arrays.asList("8s", "9c", "Tc", "Jc", "Qc"));
  private static final List<String> nonConsecutiveCardsSameColors = new ArrayList<>(
      Arrays.asList("6d", "9d", "Qd", "Jd", "Ad"));
  private static final List<String> nonConsecutiveCardsDifferentColors = new ArrayList<>(
      Arrays.asList("8s", "3c", "Td", "Jc", "2c"));
  private static final List<String> straightFlush = new ArrayList<>(
      Arrays.asList("2c", "3c", "4c", "5c", "Ac"));
  private static final List<String> royalFlush = new ArrayList<>(
      Arrays.asList("Td", "Jd", "Qd", "Kd", "Ad"));

  @Test
  public void testIsFlush() {
    Assert.assertTrue(Card.isFlush(nonConsecutiveCardsSameColors));
    Assert.assertFalse(Card.isFlush(consecutiveCardsSameColors));
    Assert.assertFalse(Card.isFlush(consecutiveCardsDifferentColors));
    Assert.assertFalse(Card.isFlush(nonConsecutiveCardsDifferentColors));
    Assert.assertFalse(Card.isFlush(royalFlush));
    Assert.assertFalse(Card.isFlush(straightFlush));
  }

  @Test
  public void testAreCardsSameColors() {
    Assert.assertTrue(Card.areSameColor(consecutiveCardsSameColors));
  }

  @Test
  public void testAreCardsNotSameColors() {
    Assert.assertFalse(Card.areSameColor(consecutiveCardsDifferentColors));
  }

  @Test
  public void testAreCardsConsecutive() {
    Assert.assertTrue(Card.areConsecutive(consecutiveCardsSameColors));
  }

  @Test
  public void testAreCardsNotConsecutive() {
    Assert.assertFalse(Card.areConsecutive(nonConsecutiveCardsDifferentColors));
  }
}
