package com.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class IsFlush {

  enum Card {

    //clubs
    TWO_OF_CLUBS("2c"), THREE_OF_CLUBS("3c"), FOUR_OF_CLUBS("4c"), FIVE_OF_CLUBS(
        "5c"), SIX_OF_CLUBS("6c"), SEVEN_OF_CLUBS("7c"), EIGHT_OF_CLUBS("8c"), NINE_OF_CLUBS(
        "9c"), TEN_OF_CLUBS("Tc"), JACK_OF_CLUBS("Jc"), QUEEN_OF_CLUBS("Qc"), KING_OF_CLUBS(
        "Kc"), ACE_OF_CLUBS("Ac"),

    //diamonds
    TWO_OF_DIAMONDS("2d"), THREE_OF_DIAMONDS("3d"), FOUR_OF_DIAMONDS("4d"), FIVE_OF_DIAMONDS(
        "5d"), SIX_OF_DIAMONDS("6d"), SEVEN_OF_DIAMONDS("7d"), EIGHT_OF_DIAMONDS(
        "8d"), NINE_OF_DIAMONDS(
        "9d"), TEN_OF_DIAMONDS("Td"), JACK_OF_DIAMONDS("Jd"), QUEEN_OF_DIAMONDS(
        "Qd"), KING_OF_DIAMONDS(
        "Kd"), ACE_OF_DIAMONDS("Ad"),

    //spades
    TWO_OF_SPADES("2s"), THREE_OF_SPADES("3s"), FOUR_OF_SPADES("4s"), FIVE_OF_SPADES(
        "5s"), SIX_OF_SPADES("6s"), SEVEN_OF_SPADES("7s"), EIGHT_OF_SPADES("8s"), NINE_OF_SPADES(
        "9s"), TEN_OF_SPADES("Ts"), JACK_OF_SPADES("Js"), QUEEN_OF_SPADES("Qs"), KING_OF_SPADES(
        "Ks"), ACE_OF_SPADES("As"),

    //hearts
    TWO_OF_HEARTS("2h"), THREE_OF_HEARTS("3h"), FOUR_OF_HEARTS("4h"), FIVE_OF_HEARTS(
        "5h"), SIX_OF_HEARTS("6h"), SEVEN_OF_HEARTS("7h"), EIGHT_OF_HEARTS("8h"), NINE_OF_HEARTS(
        "9h"), TEN_OF_HEARTS("Th"), JACK_OF_HEARTS("Jh"), QUEEN_OF_HEARTS("Qh"), KING_OF_HEARTS(
        "Kh"), ACE_OF_HEARTS("Ah");

    /**
     * Card String representation
     */
    private final String notation;

    /**
     * Card constructor
     */
    Card(String notation) {
      this.notation = notation;
    }

    public String getNotation() {
      return notation;
    }


    /**
     * Checks if all the cards are from same color
     */
    public static boolean areSameColor(List<String> notations) {

      for (int i = 0; i < notations.size() - 1; i++) {
        if (!notations.get(i).substring(1).equals(notations.get(i + 1).substring(1))) {
          return false;
        }
      }

      return true;
    }

    /**
     * Checks if cards are consecutive
     */
    public static boolean areConsecutive(List<String> notations) {
      List<Integer> list = new ArrayList<Integer>();
      final int ace = 14;
      final int checkConsecutiveWithAce = 28;

      for (String notation : notations) {

        switch (notation.substring(0, 1)) {
          case "T":
            list.add(Integer.parseInt("10"));
            break;
          case "J":
            list.add(Integer.parseInt("11"));
            break;
          case "Q":
            list.add(Integer.parseInt("12"));
            break;
          case "K":
            list.add(Integer.parseInt("13"));
            break;
          case "A":
            list.add(Integer.parseInt("14"));
            break;
          default:
            list.add(Integer.parseInt(notation.substring(0, 1)));
        }
      }

      Collections.sort(list);
      System.out.println(list + " sorted list");

      /**
       * We check the case where we have Straight with A 2 3 4 5
       * If list contain 14 (which is the Ace card) we check the whole sum.
       * If the whole sum is 28, that means we have Straight with A 2 3 4 5
       */
      if (list.contains(ace)) {
        int sum = list.stream().mapToInt(Integer::intValue).sum();
        if (sum == checkConsecutiveWithAce) {
          return true;
        }
      }

      //iterates trough sorted list and comparing if pairs are consecutive
      for (int i = 0; i < list.size() - 1; i++) {
        if (list.get(i) + 1 != list.get(i + 1)) {
          return false;
        }
      }

      return true;
    }

    /**
     * Get cards notations from specific file
     */
    public static List<String> getNotationsFromFile(String filePath) throws FileNotFoundException {
      File file = new File(filePath);
      Scanner scanner = new Scanner(file);
      List<String> notationsList = new ArrayList<>();

      notationsList.addAll(Arrays.asList(scanner.nextLine().split(" ")));
      scanner.close();

      return notationsList;
    }

    /**
     * Checks if input is Flush
     */
    public static boolean isFlush(List<String> notations) {
      if (Card.areSameColor(notations) && !Card.areConsecutive(notations)) {
        return true;
      }
      return false;
    }
  }

  public static void main(String[] args) throws IOException {

    boolean result;
    result = Card.isFlush(Card.getNotationsFromFile("src/main/resources/Input.txt"));

    FileWriter fileWriter = new FileWriter("src/main/resources/Output.txt");

    fileWriter.write(Boolean.toString(result));
    fileWriter.close();

  }

}
